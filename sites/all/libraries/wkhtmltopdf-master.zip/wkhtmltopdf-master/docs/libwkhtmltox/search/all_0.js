var searchData=
[
  ['backlinks',['backLinks',['../structwkhtmltopdf_1_1settings_1_1TableOfContent.html#a5105106cf55612b56b906261b025e293',1,'wkhtmltopdf::settings::TableOfContent']]],
  ['bottom',['bottom',['../structwkhtmltopdf_1_1settings_1_1Margin.html#a47f1c65f6e4ec9703232c627f7cffa30',1,'wkhtmltopdf::settings::Margin']]]
];
