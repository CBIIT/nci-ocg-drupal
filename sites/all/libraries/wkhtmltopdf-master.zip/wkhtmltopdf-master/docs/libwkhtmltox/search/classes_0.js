var searchData=
[
  ['cropsettings',['CropSettings',['../structwkhtmltopdf_1_1settings_1_1CropSettings.html',1,'wkhtmltopdf::settings']]]
];
