---
name: "⛔ Packaging issue"
about: See https://github.com/wkhtmltopdf/packaging for packaging issues.

---

wkhtmltopdf has its own dedicated repository for packaging. Please open your
packaging-related issue at https://github.com/wkhtmltopdf/packaging

Thanks!
