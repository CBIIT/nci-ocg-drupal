# [HISTORY.JS IS NOW COMMUNITY MANAGED! :cake: <br/> THIS IS JUST BALUPTON'S FORK! :cake: <br/> CLICK HERE TO BE TAKEN TO THE NEW REPO! :cake: <br/> ![Dance](http://i683.photobucket.com/albums/vv191/Beckybert/Dancers/dancinstickman.gif)](https://github.com/browserstate/history.js)

[For the backstory of how and why this came to be, check out this talk](http://www.youtube.com/watch?v=nt4Gt6-T8N0&list=PLYVl5EnzwqsQs0tBLO6ug6WbqAbrpVbNf&index=3)
